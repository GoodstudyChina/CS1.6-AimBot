#if !defined( WRECTH )
#define WRECTH

typedef struct rect_s
{
	int				left, right, top, bottom;
} wrect_t;

#endif